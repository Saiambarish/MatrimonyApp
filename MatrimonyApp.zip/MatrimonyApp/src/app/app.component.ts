import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, MatButtonModule, RouterLink, DashboardComponent, HttpClientModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})


export class AppComponent {
    title = 'matrimony-app';
    buttonVisible:boolean=true
    constructor(private router: Router) { }

  ngOnInit(): void {
    // Check the current route and navigate to default if it's not the default route
    // if (this.router.url !== '') {
    //   this.router.navigate(['']);
    // }
    
  }
  onClick(){
    this.router.navigate(['/dashboard'])
    this.buttonVisible=false
  }
}
