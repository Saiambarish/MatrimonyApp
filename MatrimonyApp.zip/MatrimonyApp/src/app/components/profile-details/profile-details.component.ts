import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { ActivatedRoute, Router } from '@angular/router';
import { ProfileListService } from '../../services/profile-list.service';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile-details',
  standalone: true,
  imports: [MatButtonModule, MatCardModule, CommonModule],
  providers: [ProfileListService],
  templateUrl: './profile-details.component.html',
  styleUrl: './profile-details.component.scss'
})
export class ProfileDetailsComponent {
  private router = inject(Router)
  private profileListService = inject(ProfileListService);
  private activatedRoute=inject(ActivatedRoute)
  getProfileByID: any={}
  profileID:any
ngOnInit(){
this.profileID=this.activatedRoute.snapshot.params['id']
this.getProfile(this.profileID)
}

getProfile(id:any){
   this.profileListService.getProfileList().subscribe((res: any) => {
     return this.getProfileByID=res.profiles.filter((p:any)=>p.id===id).reduce((p:any)=>p)
})
}
  onBackClick() {
    this.router.navigate(['/dashboard']);
  }

  isObject(value: any): boolean {
    return value && typeof value === 'object' && !Array.isArray(value);
  }
}
