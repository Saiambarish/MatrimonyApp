import { Component, inject, OnInit } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { ProfileListService } from '../../services/profile-list.service';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { animate, keyframes, state, style, transition, trigger } from '@angular/animations';
import { MatIconModule } from '@angular/material/icon';
import {
  MatSnackBar,
  MatSnackBarAction,
  MatSnackBarActions,
  MatSnackBarLabel,
  MatSnackBarRef,
} from '@angular/material/snack-bar';
import * as kf from '../../keyframe';
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [MatCardModule, MatButtonModule, HttpClientModule, CommonModule, MatIconModule, MatSnackBarLabel, MatSnackBarActions, MatSnackBarAction],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
  providers: [ProfileListService],
  animations: [
    trigger('cardAnimator', [
      transition('* => swiperight', animate(750, keyframes(kf.swiperight))),
      transition('* => swipeleft', animate(750, keyframes(kf.swipeleft)))
    ])
  ]
})
export class DashboardComponent implements OnInit {
  private profileListService = inject(ProfileListService);
  private router = inject(Router)
  private _snackBar = inject(MatSnackBar);
  profiles: any;
  subscription: Subscription | undefined
  profileInfo: any = {}
  state: string = 'default';
  animationState: string | undefined;
  currentIndex:number=0
  allCardsSwiped = false;


  ngOnInit() {
    this.subscription = this.profileListService.getProfileList().subscribe((res: any) => {
      this.profiles = res.profiles
      // this.listProfiles();
    })
  }

  startAnimation(state:any,action?:string) {
    if (!this.animationState) {
      this.animationState = state;
      this.currentIndex++
      if(action=="Interest")
      this._snackBar.open(`Interest Sent Successfully` , "OK", {
        duration: 2000
      });
      if (action == "Shortlist")
        this._snackBar.open(`Profile Shortlisted Successfully`, "OK", {
          duration: 2000
        });
    }
    
  }

  resetAnimationState(state:any) {
    this.animationState = '';
    
    
  }


  onHomeClick() {
    this.router.navigate(['/']);
  }

profileDetails(profileId:any){
  this.router.navigate([`/profile-details/${profileId}`]);
}


  ngOnDestroy() {
    this.subscription?.unsubscribe()
  }
}
