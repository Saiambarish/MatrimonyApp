import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ProfileListService {


  constructor(private http:HttpClient) { }
  getProfileList():Observable<any>{
    return this.http.get("../assets/profiles/profiles.json")
  }
 
}
