import { Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AppComponent } from './app.component';
import { ProfileDetailsComponent } from './components/profile-details/profile-details.component';
export const routes: Routes = [
    {
        path: '', component: AppComponent, pathMatch: 'full'
    },
    {
        path: 'dashboard', component: DashboardComponent
    },
    {path:'profile-details/:id',component:ProfileDetailsComponent},
    {
        path: '**', redirectTo: '', pathMatch: 'full'
    },
];
